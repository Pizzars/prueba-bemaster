export enum MESSAGE_CODES {
  USER_NOT_FOUND
}

export const MESSAGE_CODES_TEXTS: Record<MESSAGE_CODES, string> = {
  [MESSAGE_CODES.USER_NOT_FOUND]: 'El usuario no fue encontrado'
}
