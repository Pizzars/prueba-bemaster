import React from 'react'

const BaseIcon = () => {
  return <div>BaseIcon</div>
}

export default BaseIcon
